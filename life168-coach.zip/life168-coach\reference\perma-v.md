# PERMA-V — turning a plan into practices

Life 168 tells someone **where** to act. PERMA-V tells them **how**. Reach for this whenever
a first action is too vague to start, or someone asks what to actually *do* about a
priority.

## Attribution

**PERMA** is Martin Seligman's model of well-being, set out in *Flourish* (2011):
Positivity, Engagement, Relationships, Meaning, Achievement.

**PERMA-V** adds a sixth block, **Vitality**, and is associated with Emiliya
Zhivotovskaya and The Flourishing Center's Certificate in Applied Positive Psychology
(CAPP, 2012). Credit both — Seligman for the model, Zhivotovskaya for the Vitality
extension.

## The six pillars

| Pillar | Definition |
|---|---|
| **P**ositivity | The regular experience of positive emotions. |
| **E**ngagement | Reaching flow, fully absorbed in what you are doing. |
| **R**elationships | Nurturing high quality connections with other people. |
| **M**eaning | Serving a purpose that reaches beyond yourself. |
| **A**chievement | A sense of accomplishment, progress and mastery. |
| **V**itality | Looking after the physical health of body and mind. |

## Practices to draw on

**Positivity**
- Three good things: each night, write down three things that went well.
- Savour for ten seconds: when something good happens, stop and take it in.
- Gratitude ping pong: pass an object round the table; whoever holds it names something
  they are grateful for.
- Reframe the self talk: swap "I am not good at this" for "I am working on this", or
  "I cannot do it **yet**".

**Engagement**
- Find the flow activity: puzzles, games, sport, music — anything that loses time.
- Anchor the mind: count backwards from 100 by sevens, or name animals alphabetically.
- Five senses pause: name what you can hear, see, smell, taste and feel right now.
- Breathe on a pattern: 5:5:5 (in and out for five counts, five times); square breathing
  (in, hold, out, hold, four counts each); vacuum breathing (breathe the tension in, let it
  evaporate on the way out).

**Relationships**
- Speak their love language: learn how each person best receives care, then use it.
- Affirm out loud: specific, positive, present tense.
- Unplug on purpose: screens away, to make room for conversation and play.
- Hug: physical connection builds trust and empathy faster than words.

**Meaning**
- Big P and little p: hold the large purpose, then apply your strengths to something small
  today.
- Know your strengths: a VIA character strengths assessment, then use the top one on purpose.
- Cultivate awe: break the rut of sameness — a sunset, the clouds, the scenic route home.

**Achievement**
- Vision by horizon: each life area at one year, five years, ten years.
- Make it SMART: specific, measurable, attainable, realistic, time bound.
- Find the gap: a Wheel of Life shows which area sits furthest from where they want it.
- Keep the lists: a wants list for now, a bucket list for later.

**Vitality**
- Protect sleep: a steady wind down routine is what makes rest restorative.
- Move ten minutes: walk, swim, dance — ten minutes lowers stress and lifts energy.
- Drink enough: a common rule of thumb is weight in pounds ÷ 2 = ounces of water a day.
- Food as fuel: treat eating as fuelling, and get the family into the cooking.

## Which pillar goes with which life area

The app computes this and ships it in the export, but here it is directly:

| Life area (`id`) | Pillars |
|---|---|
| Significant other (`partner`), Family (`family`), Friendships (`friends`) | R |
| Mental health / mindfulness (`mental`) | P, V |
| Spirituality / faith (`spirit`), Societal engagement (`society`) | M |
| Community / citizenship (`community`) | M, R |
| Physical health (`physical`), Daily living (`adl`), Physiological needs (`physio`) | V |
| Finances (`finances`) | A |
| Education / learning (`learning`), Job / career (`job`) | A, E |
| Offline entertainment (`offline`), Hobbies (`hobbies`) | E, P |
| Online entertainment (`online`) | E |

In a `life168-plan.json` v2 export this arrives ready made: each priority carries
`perma_v_pillars`, and `perma_v.pillars[]` marks `matches_my_priorities` with
`because_i_chose`.

## How to use it in coaching

**Only when it helps.** A person with a sharp, specific first action does not need a
practice suggested — say so and move on.

When a first action is vague ("spend more time with family", "get healthier"):

1. Find the pillars behind that priority.
2. Offer **one or two** practices, never the whole list.
3. Shrink it to this week, with a day and a duration.

> "Family is a Relationships area. The smallest version of that is unplugging — phones in a
> drawer for dinner on Tuesday and Thursday. Would that be doable this week?"

**The implementation rule that matters most:** start with a single practice, get
comfortable and consistent, then add another. Suggesting six at once is how good intentions
collapse. If someone tries to adopt several, actively talk them down to one.

Match the practice to the person. Gratitude ping pong suits a family with young children;
a professional living alone needs a different version of the same pillar.
