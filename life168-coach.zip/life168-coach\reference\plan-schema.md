# Reading `life168-plan.json`

The app's "Save my plan as a file" button produces this. Identify it by
`format: "life168.plan"`. The current version is **3**. Older files (v1, v2) still
appear — see the version notes at the end.

The app can also **read this file back in** ("Restore my plan from a file"), so a person
may be coaching from a plan they saved weeks ago on a different device. Treat the
`plan_date` and `exported` dates as real: they tell you how old the plan is.

```json
{
  "format": "life168.plan",
  "version": 3,
  "exported": "2026-09-16",
  "plan_date": "2026-09-01",

  "method": {
    "source": "Dr. Rainer Strack, Strategic Life Portfolio",
    "week_hours": 168,
    "rating_scale": { "min": -5, "max": 5, "neutral": 0, "note": "..." },
    "quadrant_lines": {
      "importance": 0,
      "satisfaction": 0,
      "note": "The chart is sliced by two independent lines..."
    },
    "definitions": { "pressure": "...", "target_hours": "...", "time_gap": "..." }
  },

  "context": {
    "great_life": "Time with people I love and my health.",
    "purpose": "To help young people plan on purpose.",
    "vision_3_to_5_years": "Semi retired, healthy, debt free."
  },

  "week": {
    "hours_available": 168,
    "hours_placed": 168,
    "areas": [
      {
        "id": "partner",
        "name": "Significant other",
        "group": "Relationships",
        "importance": 5,
        "satisfaction": -4,
        "hours_per_week": 6,
        "quadrant": "Priority gap",
        "pressure": 90,
        "target_hours": 14.5,
        "time_gap": 8.5
      }
    ]
  },

  "priorities": [
    {
      "rank": 1,
      "id": "partner",
      "name": "Significant other",
      "pressure": 90,
      "importance": 5,
      "satisfaction": -4,
      "hours_per_week": 6,
      "better_looks_like": "A real evening together every week.",
      "begin_or_do_more_of": "A standing Friday date night",
      "reduce_or_stop": "Working past 7pm",
      "shift": "Two work evenings a week",
      "first_action": "Book Friday dinner",
      "check_in_date": "2026-09-12",
      "how_i_will_know": "Four date nights next month",
      "perma_v_pillars": ["R"]
    }
  ],

  "perma_v": {
    "note": "Six building blocks of a flourishing life...",
    "pillars": [
      {
        "key": "R",
        "name": "Relationships",
        "definition": "Nurturing high quality connections with other people.",
        "matches_my_priorities": true,
        "because_i_chose": ["Partner"],
        "practices": ["Speak their love language. ...", "..."]
      }
    ]
  },

  "timeline": [
    {
      "milestone_days": 30,
      "by_date": "2026-10-01",
      "focus": [ { "area": "Significant other", "action": "Book Friday dinner" } ]
    }
  ]
}
```

## Notes

- `week.areas` is **sorted by pressure, highest first**, and contains only areas the person
  finished rating. Fewer than 16 entries means the survey is incomplete — worth mentioning.
- `priorities` is the **top three by pressure**, and mirrors Part 5 of the app.
- **Empty strings mean genuinely unanswered.** Do not invent content for them. In the pasted
  text version the same thing appears as `(not filled in)`.
- `hours_placed` vs `hours_available` is the honesty check. Well short of 168 means
  unaccounted time; over means probable double counting.
- `target_hours` and `time_gap` are rounded to one decimal. `time_gap` may be negative.
- Dates are `YYYY-MM-DD`. `plan_date` is the user's confirmed start date; the 30/60/90
  dates are derived from it.

## The quadrant lines (version 3)

The chart is split by **two independent lines** the person can drag on the chart or set
with sliders:

- `method.quadrant_lines.importance` — a **horizontal** cut on the importance axis
- `method.quadrant_lines.satisfaction` — a **vertical** cut on the satisfaction axis

Both default to **0** (the neutral point) and range **−4 to +4 in half steps**. An area
counts as "high" on an axis when its rating is **greater than or equal to** that axis's
cut. Every `quadrant` label in `week.areas` was computed against these two values, so
read them accordingly — a person who dragged the importance line up to +2 has deliberately
narrowed what counts as a priority. That is a choice worth asking about, not correcting.

## Version differences

| Version | What changed |
|---|---|
| **3** | `method.quadrant_line` (one number) became `method.quadrant_lines` (an object with `importance` and `satisfaction`). Everything else is unchanged from v2. |
| **2** | Added `perma_v` (all six pillars, `matches_my_priorities`, `because_i_chose`) and `perma_v_pillars` on each priority. |
| **1** | The original shape. No `perma_v`; a single `quadrant_line`. |

Reading an older file:

- A v1 or v2 file has one `quadrant_line`. Treat it as **both** lines set to that value —
  that is exactly how the app restores it.
- A v1 file has no `perma_v`. Fall back to the table in `reference/perma-v.md`.

## Comparing two exports

If someone shares an older and a newer file, the most useful comparison is per area:
importance, satisfaction, hours, and pressure. A satisfaction that moved from −4 to −1 is
real progress even if the hours barely changed — say so. Also compare the two
`quadrant_lines`: if they moved between exports, the person has changed what they count as
a priority, which is itself a meaningful signal.
