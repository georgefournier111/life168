# The Life 168 method

Based on Dr. Rainer Strack's Strategic Life Portfolio ("Use Strategic Thinking to Create
the Life You Want", TED / Harvard Business Review).

The idea: treat your life the way a strategist treats a portfolio. There are 168 hours in
a week. Where they actually go, versus where they should go, is a strategy question.

## The six parts of the survey

1. **The big picture** — three written questions: what a great life means to you, your life
   purpose, and what life should look like in 3 to 5 years.
2. **Rate your life in base 168** — for each of 16 areas: importance, satisfaction, and
   hours per week. Hours must total about 168, with no activity counted twice.
3. **Quick check** — validation that hours add up and everything is rated.
4. **See your portfolio** — a bubble chart: satisfaction on X, importance on Y, bubble size
   is weekly hours. Plus a diagnostics table.
5. **Change 3 Things** — the three highest pressure areas become concrete commitments.
6. **Your action plan** — a one page 30/60/90 day plan.

## The 16 strategic life units, in 6 areas

| Area | Units (`id`) |
|---|---|
| Relationships | Significant other (`partner`), Family (`family`), Friendships (`friends`) |
| Body, mind & spirituality | Mental health / mindfulness (`mental`), Spirituality / faith (`spirit`), Physical health / sports (`physical`) |
| Community & society | Societal engagement (`society`), Community / citizenship (`community`) |
| Job, learning & finances | Finances (`finances`), Education / learning (`learning`), Job / career (`job`) |
| Interests & entertainment | Offline entertainment (`offline`), Online entertainment (`online`), Hobbies / interests (`hobbies`) |
| Personal care | Activities of daily living (`adl`), Physiological needs (`physio`) |

Sleep sits under Physiological needs and is usually the largest single block (8 hours a
night is 56 of the 168).

## The scales

Importance and satisfaction both use an **11 point scale from −5 to +5**, where **0 is
neutral**. This replaced an earlier 1–10 scale specifically because a signed scale
separates "actively dissatisfied" from "fine" far better than a low positive number does.

## The three calculations

Internally the app shifts both ratings onto a 0–10 basis, `pos(v) = v + 5`, so the
weighting stays positive.

**Pressure** — how loudly an area is asking for attention. Range 0 to 100.

```
pressure = pos(importance) × (10 − pos(satisfaction))
```

So importance +5, satisfaction −4 gives `10 × (10 − 1)` = **90**.

**Target hours** — what the week would look like if time simply followed importance.

```
target_hours = 168 × pos(importance) / Σ pos(importance) across all rated areas
```

A compass, not a schedule. Nobody should literally rearrange their week to match it.

**Time gap** — `target_hours − actual_hours`. Positive suggests an area may be starved of
time; negative suggests hours that might be won back.

## The four quadrants

Split by **two independent lines** the person can drag on the chart or set with sliders: a
horizontal cut on **importance** and a vertical cut on **satisfaction**. Both default to
**0** (the neutral point) and range −4 to +4 in half steps. An area is "high" on an axis
when its rating is greater than or equal to that axis's cut. In a `life168-plan.json` they
arrive as `method.quadrant_lines.importance` and `.satisfaction`; older v1/v2 files carried
a single shared `quadrant_line`, which the app treats as both lines set to that value.

| Quadrant | Meaning | Coaching stance |
|---|---|---|
| **Priority gap** (high importance, low satisfaction) | Matters, going badly | Where the work is. Dig into why, then act. |
| **Strategic strength** (high importance, high satisfaction) | Matters, going well | Protect and sustain. Name these out loud. |
| **Lower priority** (low importance, low satisfaction) | Neither matters much nor going well | Monitor, or let go on purpose. |
| **Nice to have** (low importance, high satisfaction) | Going well, matters less | Keep deliberately, or trim if it eats time. |

The upper-left **Priority gap** quadrant is the heart of the method.

## The 30/60/90 structure

- **Days 1–30** — each of the three priorities gets one *first action*.
  Milestone: all three first actions taken.
- **Days 31–60** — more of the new habit, less of what crowds it out.
  Benchmark: each change is a weekly habit.
- **Days 61–90** — the measure of progress.
  Milestone: a full cycle finished, ready to re-map the week.

Dates are calculated from the user's confirmed start date.

## Where the data lives

Entirely in the user's own browser (local storage). Nothing is uploaded, there is no
account, and the developer cannot see any of it. Anything you receive, the user chose to
share with you. Treat it accordingly.
