# Life 168 Coach — a skill for Claude

Turns Claude into a coach for your **Life 168** strategic life plan. It knows the method,
reads the numbers correctly, and helps you follow through on the plan you wrote — instead
of giving generic life advice.

Life 168: https://life168.org · The app: https://app.life168.org

## What is in here

| File | Purpose |
|---|---|
| `SKILL.md` | The skill itself: how to read a plan and how to coach |
| `reference/method.md` | The framework, the 16 areas, and the exact formulas |
| `reference/coaching.md` | Playbooks for the four session types |
| `reference/perma-v.md` | PERMA-V practices, for turning a vague action into a real one |
| `reference/plan-schema.md` | The `life168-plan.json` format |

## Install it

**Claude Desktop / Claude.ai** — Settings → Capabilities → Skills → upload
`life168-coach.zip`.

**Claude Code** — unzip the folder into either of these, then restart:

```bash
~/.claude/skills/life168-coach        # available everywhere
.claude/skills/life168-coach          # just this project
```

## Use it

1. Finish the survey at https://app.life168.org
2. At the bottom, under **Take your plan with you**, pick what you want help with and press
   **Copy my plan for AI** (or **Save my plan as a file**)
3. Paste it into Claude, or attach `life168-plan.json`
4. Later, on any device, **Restore my plan from a file** loads that same file back into the
   app — so you can keep coaching from where you left off, and compare a fresh export against
   the old one

Claude picks the skill up automatically once it sees a Life 168 plan.

## The four modes

- **Coach me through it** — accountability, one question at a time
- **Stress test my plan** — finds what is vague or unrealistic before it fails
- **Make my first actions specific** — turns intentions into this-week actions
- **Run my 30 day check in** — honest review, then a revised plan for days 31 to 60

## A note on privacy

Your Life 168 answers live only in your own browser. Nothing is uploaded and nobody else
can see them. When you paste your plan into an AI assistant, you are sending that text to
that company, and their terms apply. Your plan can hold personal detail about your health,
relationships, work, and money — so share only what you are comfortable sharing.

## Not a substitute for professional help

This is a planning aid. It does not give medical, psychiatric, financial, or legal advice.
If something serious is going on, please talk to a qualified professional. In an emergency,
contact your local emergency services.

---

Method: Dr. Rainer Strack, Strategic Life Portfolio ("Use Strategic Thinking to Create the
Life You Want", TED / Harvard Business Review).

Copyright 2026 George M Fournier, MBA v8.1.26
